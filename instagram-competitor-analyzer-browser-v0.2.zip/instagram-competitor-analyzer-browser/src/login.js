import "dotenv/config"; import {ctx,save} from "./browser.js";
const {browser,context}=await ctx(false);const page=await context.newPage();await page.goto("https://www.instagram.com/accounts/login/",{waitUntil:"domcontentloaded",timeout:60000});
console.log("\nLogin manually. Complete 2FA/CAPTCHA yourself. When Instagram is fully loaded, return here and press ENTER.\n");
process.stdin.resume();process.stdin.once("data",async()=>{await save(context);console.log("Session saved locally.");await browser.close();process.exit(0)});