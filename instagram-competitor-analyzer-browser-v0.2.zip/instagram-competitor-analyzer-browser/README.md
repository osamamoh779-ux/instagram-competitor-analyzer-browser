# Instagram Competitor Analyzer Browser
Free local backend: your PC runs Playwright; Cloudflare Tunnel exposes the MCP endpoint.

## Install (Windows PowerShell)
```powershell
npm install
npx playwright install chromium
Copy-Item .env.example .env
```
## Login once
```powershell
npm run login
```
Log into Instagram manually. Complete 2FA/CAPTCHA yourself, then return to PowerShell and press ENTER. Session data stays in `sessions/` and is gitignored.

## Run
```powershell
npm start
```
Test `http://127.0.0.1:3000/health`.

## Tunnel
Install `cloudflared`, then in a second terminal:
```powershell
cloudflared tunnel --url http://127.0.0.1:3000
```
Use the HTTPS URL it prints plus `/mcp` as the plugin MCP URL.

Never upload `sessions/`, passwords, cookies, or 2FA codes. Do not bypass Instagram security controls.
